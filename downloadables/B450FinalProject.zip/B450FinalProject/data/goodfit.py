import pandas as pd
import fitter as f
import matplotlib.pyplot as plt 

from fitter import get_distributions
print(get_distributions())
data = pd.read_csv("datas.csv")
head = data.head()
print(head)
    
'''
dist_med = f.Fitter(data["medium"], distributions=["uniform",
                                      "beta",
                                      "gamma",
                                      "lognorm",
                                      "norm",
                                      "dweibull"],timeout=500
                    )
dist_med.fit()
dist_med.summary()


dist_soft = f.Fitter(data["soft"], distributions=["uniform",
                                      "beta",
                                      "gamma",
                                      "lognorm",
                                      "norm",
                                      "dweibull"],timeout=500
                     distributions=["uniform",
                                                           "beta",
                                                           "gamma",
                                                           "lognorm",
                                                           "norm",
                                                           "weibull_max","expon","weibull_min"],timeout=500)
                    )
dist_soft.fit()
dist_soft.summary()
'''


dist_fit = f.Fitter(data["medium"])

dist_fit.fit()
#dist_fit.summary().to_csv("virtuallaptimes.csv")
print(dist_fit.summary())
plt.show()


