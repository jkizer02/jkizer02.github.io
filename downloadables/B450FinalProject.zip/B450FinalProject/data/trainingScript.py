# -*- coding: utf-8 -*-
"""
Created on Fri Nov 24 13:49:22 2023

@author: jarre
"""

import pandas as pd
import numpy as np
import enchant
import statsmodels.formula.api as smf
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error
import torch
from torch import nn
from torch.utils.data import Dataset,DataLoader
from torchvision import datasets
from torchvision.transforms import ToTensor, Lambda

df = pd.read_csv("networktrainingdata.csv")
#create target
target = df['LABEL'].values
#create features
features = df[["sc",
                 "vsc",
                 "lapsleft",
                 "sage",
                 "mage",
                 "hage",]]
#split the data sets into test and train
X_train, X_test, y_train, y_test = train_test_split(features, target,
                                                    test_size=0.3,
                                                    random_state=100,
                                                    shuffle=True)

class MyDataset(Dataset):
 
  def __init__(self,file_name):
    df=pd.read_csv(file_name)
 
    x=df.iloc[:,0:6].values
    y=df.iloc[:,6].values
 
    self.x_train=torch.tensor(x,dtype=torch.float32)
    self.y_train=torch.tensor(y,dtype=torch.float32)
 
  def __len__(self):
    return len(self.y_train)
   
  def __getitem__(self,idx):
    return self.x_train[idx],self.y_train[idx]

myDs=MyDataset("networktrainingdata.csv")
trainDs = 1
testDs = 2
train_loader=DataLoader(myDs,batch_size=1,shuffle=True)
test_laoder = 2

model = LinearRegression()
model.fit(X_train,y_train)
#output R - sqaured and rmse
y_pred = model.predict(X_test)
print("\n\n\nScikit learn model 1")
print("The R-squared score is {:.4f}".format(r2_score(y_test,y_pred)))
print("The Root Mean Squared error is {:.4f}".format(np.sqrt(mean_squared_error(y_test,y_pred))))


class NeuralNetwork(nn.Module):
    def __init__(self):
        super(NeuralNetwork, self).__init__()
        self.flatten = nn.Flatten()
        self.linear_relu_stack = nn.Sequential(
            nn.Linear(6, 4),
            nn.ReLU(),
            nn.Linear(4, 2),
            nn.ReLU()
        )

    def forward(self, x):
        x = self.flatten(x)
        x = self.linear_relu_stack(x)
        x = nn.functional.log_softmax(x,dim=0)
        return x
model = NeuralNetwork()
learning_rate = 1e-3
batch_size = 64
epochs = 5

#full code for the optimization loop
#optimizing through the training data
def train_loop(dataloader, model, loss_fn, optimizer):
    size = len(dataloader.dataset)
    for batch, (x, y) in enumerate(dataloader):        
        # Compute prediction and loss
        print(x)
        pred = model(x)
        print(pred)
        loss = loss_fn(pred, y)
        
        # Backpropagation, get the gradiant, move backwards throught the network, go to next.
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        if batch % 100 == 0:
            loss, current = loss.item(), batch * len(x)
            print(f"loss: {loss:>7f}  [{current:>5d}/{size:>5d}]") #every 100 batchs, print the loss and current precent complete

#optimizing for the test data, go through and compute the loss and correct for the test data
#print the precentage test_loss and correct 
def test_loop(dataloader, model, loss_fn):
    size = len(dataloader.dataset)
    test_loss, correct = 0, 0

    with torch.no_grad():
        for X, y in dataloader:
            pred = model(X)
            test_loss += loss_fn(pred, y).item()
            correct += (pred.argmax(1) == y).type(torch.float).sum().item()
            
    test_loss /= size 
    correct /= size
    print(f"Test Error: \n Accuracy: {(100*correct):>0.1f}%, Avg loss: {test_loss:>8f} \n")
    
    
# Initialize the loss function
loss_fn = nn.CrossEntropyLoss()

#all optimiztion logic is in the optimizer object
optimizer = torch.optim.SGD(model.parameters(), lr=learning_rate)
#epochs = 28
epochs = 1
#the optimization loop
for t in range(epochs):
    print(f"Epoch {t+1}\n-------------------------------")
    train_loop(train_loader, model, loss_fn, optimizer)

#save the model
torch.save(model.state_dict(), "data/model.pth")

print("Saved PyTorch Model State to model.pth")

print("Done!")

#softmax = nn.Softmax(dim=1)
#pred_probab = softmax(logits)
