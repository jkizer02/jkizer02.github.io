# -*- coding: utf-8 -*-
"""
Authors Professor Wheedle
purpose: to generate graphs

#Palette 
78C0E0 - lightest blue 
449DD1
3943B7
150578 -
0E0E52 - darkest blue sleep 

7785AC 
5B2A86 
360568 - sad
"""
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

#-------------------------------FEILDS--------------------------------
dataex = pd.read_excel(r"C:\Users\jarre\Downloads\B104FinalProjectFile.xlsx")
df = pd.DataFrame(data=dataex) #take the excel into dataframe
df = df.fillna(0) #use zeros for nulls

#set columns we need to do math as int datatypes
df['sad'] = df['sad'].astype(int)
df['gender'] = df ['gender'].astype(int)
df['sleep'] = df['sleep'].astype(int)
df['grade'] = df['grade'].astype(int)

#-------------------------------FUNCTIONS--------------------------------

#input: a menu displaying the valid options, 
#       a prompt for the user to see, 
#       and the end points of the valid options.
#Process: validates user input
#output: returns valid input from the user 
def validate(options,prompt,m,M):
    try:
        print('\n--------------------------------------------------------------------\n')
        print(options)
        validInput=int(input(prompt))
        if validInput>=m or validInput<=M:
            return validInput
        else:
            return validate(options,prompt,m,M)
    except: 
        print('--------------------------------------------------------------------\n')
        print("I'm sorry, it looks like we do not have that graph. Please enter one of our selections")
        return validate(options,prompt,m,M) 
           
#------------------------------------------------------------------------------------
    
#Process: displays a heatMap showing the crosssection and relationship between 2 or more columns
def Heatmap():
    fid, ax = plt.subplots(figsize=(15,8))
    sns.heatmap(dataex.corr(),center=0,cmap='Purples',annot=True)
    ax.set_title("Heatmap showing possible relationships\n", fontsize=25)
    plt.show()
#------------------------------------------------------------------------------------
    
#purpose: to display 2 circle graphs, 
#         the first, the total number of those who feel sad vs those who dont
#         the second, the total number of those who slept vs those who dont
#input:  a variable x to partition by
#process: creates pie charts for both columns. 
#output: returns true if it works and False if not
def pieCharts(x=4):
    try:
    #FIELDS
        fig, (sadg, slept) = plt.subplots(1,2,figsize=(10,6))
        #grouping the df so we can sum them
        pieChartSaddf = df.groupby(['sad','sleep'])['sad'].agg(['count'])
        #adding the sum of sad answers and notsad answers
        sadsleep = int(sum(pieChartSaddf['count'][1][x:8]))
        sadnosleep = int(sum(pieChartSaddf['count'][1][1:x]))
        pieChartsadSleep = sadsleep/(sadnosleep+sadsleep)*100, sadnosleep/(sadnosleep+sadsleep)*100
        
        #colors
        colorSad = ['#360568','#7785AC']#360568

        #adding sums of healthy sleep vs non healthy sleep according to cdc
        nosadsleep = int(sum(pieChartSaddf['count'][2][x:8]))
        nosadnosleep = int(sum(pieChartSaddf['count'][2][1:x]))
        pieChartnosadSleep = nosadsleep/(nosadnosleep+nosadsleep)*100, nosadnosleep/(nosadnosleep+nosadsleep)*100
        myexplode=[0.08, 0]
        
        colorSleep=['#150578','#78C0E0']#78C0E0
        
        #variabls and formatting for both piecharts
        x+=3
        salabels = [f"depressed with {x} or more hours of sleep" , f'depressed with less then {x} hours of sleep']
        sadg.pie(pieChartsadSleep,explode=myexplode,colors=colorSad, autopct='%1.1f%%', shadow=True, startangle=180,textprops =dict(color="w"), center = (-2,0))
        
        sllabels = [f'not depressed with {x} or more hours of sleep' , f'not depressed with less then {x} hours of sleep']
        slept.pie(pieChartnosadSleep, explode=myexplode,colors=colorSleep, autopct='%1.1f%%', shadow=True, startangle=180,textprops =dict(color="w"), center = (2,0))
        
        #final style adjustments
        slept.legend(sllabels,loc="best")
        sadg.legend(salabels, loc="best")
        #sadg.subtitle('Depressed')
        sadg.axis('equal')
        slept.axis('equal')
        #plt.title('The amount of sleep gotten by depressed vs non depressed students \n')
        plt.show()
        
        #it works 
        return (sadg,slept)
    except:
        #doesnt work
        print('pie chart broke')
        return False
    
#------------------------------------------------------------------------------------
    

#purpose: show an overall percentage of where the answers fell for the responses
#input:   the partitioning x for the data
#process: groups by sleep and displays 2 precentages
#output:  a single piechart displaying the partitioned percentages.
def piechartBase(x):
    fig, (slp) = plt.subplots(1, 1,figsize=(10,6))
                                      
    pychartsleep=df.groupby(['sleep'])['sleep'].agg(['count'])

    sleepyes = int(sum(pychartsleep['count'][x:8]))
    sleepno = int(sum(pychartsleep['count'][1:x]))
    piechartSleep = sleepyes/(sleepyes+sleepno)*100, sleepno/(sleepyes+sleepno)+100
    
    colorSleep=['#150578', '#78C0E0']#150578
    x+=3
    salabels = [f"precentage of students with {x} or more hours of sleep" , f'precentage of students with less then {x} hours of sleep']
    myexplode= [0.08, 0]
    slp.pie(piechartSleep,explode=myexplode, colors=colorSleep, autopct='%1.1f%%', shadow=True, startangle=45,textprops =dict(color="w"), center = (0,0))
    slp.legend(salabels, loc="best")
    slp.axis('equal')
    plt.show()
    
#------------------------------------------------------------------------------------

#purpose: to create a histogram showing overall negative answers by grades, showing possible other areas to expand the research
#input:  a sl variable that is used to partition the data of good vs bad sleep amount. 
#process: group the series together before displaying the aggregated results
#output:  a 4 xticked histogram grouped by grade. each group should have 4 columns, depressed, sleep, grades, and activity.
def completeHistogram(sl):
    Histsleep= df.groupby(['class','sleep'])['class'].agg(['count'])
    Histsad=df.groupby(['class','sad'])['class'].agg(['count'])
    Histgrade=df.groupby(['class','grade'])['class'].agg(['count'])
    Histactivity=df.groupby(['class','activity'])['class'].agg(['count'])
    
    classtotal=df.groupby(['class'])['class'].agg(['count'])
    freshment= int((classtotal['count'][1]))
    sophomoret= int((classtotal['count'][2]))
    juniort = int((classtotal['count'][3]))
    seniort = int((classtotal['count'][4]))
    
    fsleep = int(sum(Histsleep['count'][1][1:sl]))
    Sosleep = int(sum(Histsleep['count'][2][1:sl]))
    jsleep =int(sum(Histsleep['count'][3][1:sl]))
    Sesleep=int(sum(Histsleep['count'][4][1:sl]))

    fsad = int((Histsad['count'][1][1]))
    Sosad = int((Histsad['count'][2][1]))
    jsad =int((Histsad['count'][3][1]))
    Sesad=int((Histsad['count'][4][1]))

    fgrade = int(sum(Histgrade['count'][1][2:6]))
    Sograde = int(sum(Histgrade['count'][2][2:6]))
    jgrade =int(sum(Histgrade['count'][3][2:6]))
    Segrade =int(sum(Histgrade['count'][4][2:6]))

    factivity = int(sum(Histactivity['count'][1][:5]))
    Soactivity= int(sum(Histactivity['count'][2][:5]))
    jactivity =int(sum(Histactivity['count'][3][:5]))
    Seactivity=int(sum(Histactivity['count'][4][:5]))
    
    sleep=[fsleep, Sosleep, jsleep, Sesleep]
    sad=[fsad, Sosad, jsad, Sesad]
    grade=[fgrade, Sograde, jgrade, Segrade ]
    activity=[factivity, Soactivity, jactivity, Seactivity]
    ctotal=[freshment,sophomoret,juniort,seniort]
    for i in range(0,4):
        sleep[i]=sleep[i]/ctotal[i]*100
        sad[i]=sad[i]/ctotal[i]*100
        activity[i]=activity[i]/ctotal[i]*100
        grade[i]=grade[i]/ctotal[i]*100
   
    x = np.arange(4)

    w=0.2
    plt.bar(x-0.1, sleep, w, color= '#150578', label='Sleep')
    plt.bar(x-0.3, sad, w, color='#5B2A86', label='Depressed')
    plt.bar(x+0.1, grade, w, color='#78C0E0', label='Grade')
    plt.bar(x+0.3, activity, w, color='#7785AC', label='Activity')
   
    plt.xticks(x,['Freshman', 'Sophmore', 'Junior', 'Senior'])
    plt.yticks([10,20,30,40,50,60,70,80],['10%','20%','30%','40%','50%','60%','70%','80%'])
    plt.ylabel('Amount of students answering yes by grade')
    #kate attempting to name the axises because her computer gets angry when she attempts to label the ticks

    plt.xlabel("the grade of the students")
    #kate's computer got angry when she tried to plot the y-axis, but it was fine for the x-axis
    #kate MIGHT kill her computer because she's getting angry at it for bring angry
    plt.ylabel("Precentage")
    plt.title('Precentage of negative responses by Grade.\n')

    plt.legend(loc='best')
    #plt.title('Data by grade of Highschool')
   
    plt.show()
#------------------------------------------------------------------------------------

#purpose: to create and display a histogram showing a possible relation between sleep and depression
#process: group the series together before displaying the aggregated results
#output: either an error message or the histogram
def HistogramSleep():
    #both to the same. 
    try:
       Hist3 = df.groupby(['sleep'])['sleep'].agg(['count'])
       #print(Hist3)
       foursleep=int((Hist3['count'][1]))
       fivesleep=int((Hist3['count'][2]))
       sixsleep=int((Hist3['count'][3]))
       sevensleep=int((Hist3['count'][4]))
       eightsleep=int((Hist3['count'][5]))
       ninesleep=int((Hist3['count'][6]))
       tensleep=int((Hist3['count'][7]))
       
       #placing the above values into arrays so we can use them in the histogram
       # sad=[fSad,SoSad,JSad,SeSad]
       sleep = [foursleep, fivesleep, sixsleep, sevensleep, eightsleep, ninesleep, tensleep]
       #number of sleep responses we will be displaying
       
       x=np.arange(7)

       #bar width
       w=0.5
       #plotting the sad bars at the x value - width
       plt.bar(x,sleep,w,color='#150578')
       #plotting the sleep bars at the x value + width
       
       #labeling the axis's
       plt.xticks(x, ['4 or less','5','6','7','8','9','10 or more'])
       plt.ylabel("total responses")
       #showing what the bars represent
       plt.legend([ "Full data set's sleep"])
       plt.show()
    except:
        print('Histograms broke')
        return False
#------------------------------------------------------------------------------------

#name:    histoSad
#purpose: to visualize the precentage of depressed individuals by the amount of sleep gotten.
#output:  a 7 xtick graph that displays the overall precentage of sad answers for each catagory.
def histoSad(): 
    try:
        Hist = df.groupby(['sleep','sad'])['sleep'].agg(['count'])
        
        sad4=int(Hist['count'][1][1])
        sad5=int(Hist['count'][2][1])
        sad6=int(Hist['count'][3][1])
        sad7=int(Hist['count'][4][1])
        sad8=int(Hist['count'][5][1])
        sad9=int(Hist['count'][6][1])
        sad10=int(Hist['count'][7][1])
        sad   = [ sad4, sad5, sad6, sad7, sad8, sad9, sad10]
        total4 = int(sum(Hist['count'][1][0:3]))
        total5 = int(sum(Hist['count'][2][0:3]))
        total6 = int(sum(Hist['count'][3][0:3]))
        total7 = int(sum(Hist['count'][4][0:3]))
        total8 = int(sum(Hist['count'][5][0:3]))
        total9 = int(sum(Hist['count'][6][0:3]))
        total10 = int(sum(Hist['count'][7][0:3]))
        total = [total4,total5,total6,total7,total8,total9,total10]
        for i in range (0,7):
            sad[i]=sad[i]/total[i]*100
            
        x=np.arange(7)
        #bar width
        w=0.5
        #plotting the sad bars at the x value - width
        plt.bar(x,sad,w,color='#360568')
        #plotting the sleep bars at the x value + width
        
        #labeling the axis's
        plt.xticks(x, ['4 or less','5','6','7','8','9','10 or more'])
        plt.yticks([10,20,30,40,50,60],['10%','20%','30%','40%','50%','60%'])
        plt.ylabel("Precentage of depressed individuals")
        #showing what the bars represent
        plt.title("Precentage of depressed students by hours of sleep gotten\n")
        plt.xlabel('Hours of sleep gotten')
        
        plt.show()
        
    except:
        print('The histogram for the sad data broke.')
#------------------------------------------------------------------------------------

#name: genHisto
#Purpose: to visualize the precentage of people depressed by gender and their sleep
#output:  a 7 xticked precentage graph with 2 bars at each tick. one for each gender. 
def genHisto():
    Histgen= df.groupby(['gender', 'sleep'])['gender'].agg(['count'])
    #fig, (gen) = plt.subplots(1, 1,figsize=(10,6))
    wsleepfourless=int((Histgen['count'][1][1]))
    wsleepfive=int((Histgen['count'][1][2]))
    wsleepsix=int((Histgen['count'][1][3]))
    wsleepseven=int((Histgen['count'][1][4]))
    wsleepeight=int((Histgen['count'][1][5]))
    wsleepnine=int((Histgen['count'][1][6]))
    wsleeptenmore=int((Histgen['count'][1][7]))
    
    msleepfourless=int((Histgen['count'][2][1]))
    msleepfive=int((Histgen['count'][2][2]))
    msleepsix=int((Histgen['count'][2][3]))
    msleepseven=int((Histgen['count'][2][4]))
    msleepeight=int((Histgen['count'][2][5]))
    msleepnine=int((Histgen['count'][2][6]))
    msleeptenmore=int((Histgen['count'][2][7])) 
    
    mtotal= int(sum(Histgen['count'][2][1:8]))
    wtotal=int(sum(Histgen['count'][1][1:8]))
    
    wsleep=[wsleepfourless, wsleepfive, wsleepsix, wsleepseven, wsleepeight, wsleepnine, wsleeptenmore] 
    msleep=[msleepfourless, msleepfive, msleepsix, msleepseven, msleepeight, msleepnine, msleeptenmore]
    for i in range(0,7):
        wsleep[i]=wsleep[i]/wtotal *100
        msleep[i]=msleep[i]/mtotal * 100
    # stotal=[four, five, six, seven, eight, nine, ten]
    x=np.arange(7)    
    w = 0.4
    plt.bar(x+0.2, msleep, w, color='#78C0E0',label='Precentage of male students')
    plt.bar(x-0.2, wsleep, w, color='#7785AC' ,label= 'Precentage of female students')

    plt.xticks(x, ['4 or less','5','6','7','8','9','10 or more'])
    plt.yticks([5,10,15,20,25,30,35], ['5%','10%','15%','20%','25%','30%','35%'])
    plt.xlabel("Hours of sleep")
    plt.ylabel("Precentage")
    plt.title('Distrubtion of Hours of sleep of both female and male students\n')
    
    plt.legend(loc='best')
    #plt.title('Data by grade of Highschool')
    plt.show()
    
#------------------------------------------------------------------------------------
    
#Name:    selector
#Purpose: this is the decision structure of the program that determines what gets run.
#input:   The number the user wishes to see
def Selector(g):
    if(g==1):
        about='The SPAR program is a python script that is designed to analize data\nprovided by the cdc and collected in the Youth Risk Behavior Surveillance System\n(also reffered to as the YRBSS)'
        dat='\nSPAR is specifically designed to analyse the responses to \nquestion 25 and question 88. These questions protain to whether\nthe respondence feel sad or hopeless and how much sleep\nthey recieved.'
        
        print('--------------------------------------------------------------------\n')
        print(about)
        print(dat)
        print('\nFor more information on the YRBSS visit \nhttps://www.cdc.gov/healthyyouth/data/yrbs/index.htm')
        print('--------------------------------------------------------------------\n')
        
    elif(g==2):
        op='1. 4 or less hours of sleep\n2. 5 hours of sleep\n3. 6 hours of sleep\n4. 7 hours of sleep\n5. 8 hours of sleep\n6. 9 hours of sleep\n7. 10 or more hours of sleep'
        x=validate(op, 'Please enter the amount of sleep you wish to partition by: ', 1, 7)
        completeHistogram(x)
        
    elif(g==3):
        op='1. 4 or less hours of sleep\n2. 5 hours of sleep\n3. 6 hours of sleep\n4. 7 hours of sleep\n5. 8 hours of sleep\n6. 9 hours of sleep\n7. 10 or more hours of sleep'
        x=validate(op, 'Please enter the amount of sleep you wish to partition by: ', 1, 7)
        pieCharts(x)
        piechartBase(x)
        
    elif (g==4):
        HistogramSleep()
        genHisto()
    elif (g==5):
        Heatmap()
    elif(g==6):
        histoSad()
    elif (g==7):
        op='1. 4 or less hours of sleep\n2. 5 hours of sleep\n3. 6 hours of sleep\n4. 7 hours of sleep\n5. 8 hours of sleep\n6. 9 hours of sleep\n7. 10 or more hours of sleep'
        x=validate(op, 'Please enter the amount of sleep you wish to partition by: ', 1, 7)
        piechartBase(x)
        HistogramSleep()
        genHisto()
        Heatmap()
        pieCharts(x)
        completeHistogram(x)
        histoSad()
    return False
    
#-------------------------------OUTPUT--------------------------------
#inputed file

print('--------------------------------------------------------------------\n\n')
print('Welcome to the Spyder Python Assistant Researcher, or SPAR \n')
print('created by Kate Curry and Jarrett Kizer\n')
print('--------------------------------------------------------------------\n')
loop=True
while(loop):
    #generate graphs 
    #input
    #number of graphs available
    numberofgraphs=7
    
    #input of selections
    graphOptions = '\n\n1. About SPAR \n2. Complete Histogram\n3. Pie Charts \n4. Raw Data  \n5. HeatMap \n6. Precent depressed by hours of sleep \n7. Show me all them graphs  \n'
    GraphSelection = validate(graphOptions, "Plase enter the number for the chart you want to see: ",1,numberofgraphs) 
    #process
    #logic behind decisions
    Selector(GraphSelection)
    
    #determine whether to run again or exit
    again=validate('1. Yes, show me more graphs\n2. No, I want to see my family\n',"Would you like to see another graph: ",1,2)
    if(again==2):
        loop=False

print('--------------------------------------------------------------------\n\n')
print('Thank you for using SPAR! have a fantastic research!')
print('--------------------------------------------------------------------\n')
        

    
