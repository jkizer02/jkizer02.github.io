# -*- coding: utf-8 -*-
"""
Created on Wed Nov 22 12:56:09 2023

@author: jarre
"""
from torch.utils.data import DataLoader
from torchvision import datasets
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
from torchvision.transforms import ToTensor
import tqdm



def userInput(options,upper):
    try:
        print(options)
        out = input("enter the number for your selection: ")
        out=int(out)
        if (out <1 or out > upper):
            return userInput(options,upper)
        return out
    except:
        print("not a number, try again")
        return userInput(options,upper)

def prepareData():
    dataTrain = datasets.CIFAR10(root="data",
                                 train=True,
                                 download=True,
                                 transform=ToTensor(),)
    dataTest = datasets.CIFAR10(root="data",
                                train=False,
                                download=True,
                                transform=ToTensor(),)

    trainLoader = DataLoader(dataTrain,batch_size=64)
    testLoader = DataLoader(dataTest,batch_size=64)
    return trainLoader,testLoader



#this function is used to train the network.
#inputs:
#outputs:
def train_epoch(net,dataloader,device, lr=0.01,optimizer=None,loss_fn = nn.NLLLoss()):
    optimizer = optimizer or torch.optim.Adam(net.parameters(),lr=lr)
    #print("optim")
    net.train()
    #print("prep")
    total_loss,acc,count = 0,0,0
    for features,labels in dataloader:
        features, labels = features.to(device), labels.to(device)
        optimizer.zero_grad()
        out = net(features)
        loss = loss_fn(out,labels) #cross_entropy(out,labels)
        loss.backward()
        optimizer.step()
        total_loss+=loss
        _,predicted = torch.max(out,1)
        acc+=(predicted==labels).sum()
        count+=len(labels)
    return total_loss.item()/count, acc.item()/count

#inputs:
#outputs:
def validate(net, device, dataloader,loss_fn=nn.NLLLoss()):
    net.eval()
    count,acc,loss = 0,0,0
    with torch.no_grad():
        for features,labels in dataloader:
            features, labels = features.to(device), labels.to(device)
            out = net(features)
            loss += loss_fn(out,labels) 
            pred = torch.max(out,1)[1]
            acc += (pred==labels).sum()
            count += len(labels)
    return loss.item()/count, acc.item()/count



#inputs:
#outputs: 
def train(net,train_loader,test_loader, device,optimizer=None,lr=0.01,epochs=10,loss_fn=nn.NLLLoss()):
    optimizer = optimizer or torch.optim.Adam(net.parameters(),lr=lr)
    #print("train; optim")
    res = { 'train_loss' : [], 'train_acc': [], 'val_loss': [], 'val_acc': []}
    for ep in tqdm.trange(epochs):
        tl,ta = train_epoch(net,train_loader, device,optimizer=optimizer,lr=lr,loss_fn=loss_fn)
        #print("tl and ta")
        vl,va = validate(net, device, test_loader,loss_fn=loss_fn)
        #print("vl,va")
        print(f"\nEpoch {ep:2}, Train acc={ta:.3f}, Val acc={va:.3f}, Train loss={tl:.3f}, Val loss={vl:.3f}")
        res['train_loss'].append(tl)
        res['train_acc'].append(ta)
        res['val_loss'].append(vl)
        res['val_acc'].append(va)
    return res

class LeNet5(nn.Module):
    def __init__(self):
        super(LeNet5, self).__init__()
        self.conv1 = nn.Conv2d(3, 6, 5)
        self.pool = nn.MaxPool2d(2)
        self.conv2 = nn.Conv2d(6, 16, 5)
        self.conv3 = nn.Conv2d(16,120,5)
        self.flat = nn.Flatten()
        self.fc1 = nn.Linear(120,64)
        self.fc2 = nn.Linear(64,10)
        #self.batch1 = nn.BatchNorm2d(16)
        #self.batch = nn.BatchNorm2d(120)

    def forward(self, x):
        x = self.pool(nn.functional.relu(self.conv1(x)))
        x = self.pool(nn.functional.relu(self.conv2(x)))
        #x = self.batch1(x)
        x = nn.functional.relu(self.conv3(x))
        #x = self.batch(x)
        x = self.flat(x)
        x = nn.functional.relu(self.fc1(x))
        x = self.fc2(x)
        return x
    
 
class modifiedvgg16(nn.Module):
    def __init__(self):
        super(modifiedvgg16, self).__init__()
        self.conv1 = nn.Conv2d(3, 64, 3,1,padding = 1)
        self.conv11 = nn.Conv2d(64, 64, 3,1,padding = 1)
        self.conv2 = nn.Conv2d(64, 128, 3,1,padding = 1)
        self.conv22 = nn.Conv2d(128, 128, 3,1,padding = 1)
        self.pool = nn.MaxPool2d(kernel_size = (2,2),stride=2,padding=0,dilation=1,ceil_mode=False) 
        
        self.conv3 = nn.Conv2d(128, 256, 3,1,padding = 1)
        self.conv4 = nn.Conv2d(256,256,3,1,padding = 1)
        self.conv44 = nn.Conv2d(256,256,3,1,padding = 1)
        
        self.conv5 = nn.Conv2d(256,512,3,1,padding = 1)
        self.conv6 = nn.Conv2d(512,512,3,1,padding = 1)
        self.conv7 = nn.Conv2d(512,512,3,1,padding = 1)
        
        self.conv8 = nn.Conv2d(512,512,3,1,padding = 1)
        self.conv9 = nn.Conv2d(512,512,3,1,padding = 1)
        self.conv10 = nn.Conv2d(512,512,3,1,padding = 1)
        self.avg = nn.AdaptiveAvgPool2d((7,7))
        
        self.batch0 = nn.BatchNorm2d(64)
        self.batch1 = nn.BatchNorm2d(128)
        self.batch2 = nn.BatchNorm2d(256)
        self.batch3 = nn.BatchNorm2d(512)
        self.batch4 = nn.BatchNorm2d(512)
    
        self.fc1 = nn.Linear(512*7*7,4096)    
        self.fc2 = nn.Linear(4096, 4096)
        self.fc3 = nn.Linear(4096, 10)

    def forward(self, x):
        x = self.pool(F.relu(self.conv11(F.relu(self.conv1(x),inplace=True)),inplace=True))
        #x = F.relu(self.conv11(F.relu(self.conv1(x),inplace=True)),inplace=True)
        x = self.batch0(x)
        x = F.dropout(x, 0.5)
        x = self.pool(F.relu(self.conv22(F.relu(self.conv2(x),inplace=True)),inplace = True))
        x = self.batch1(x)
        x = F.dropout(x, 0.5)
        
        x  = self.pool(F.relu(self.conv44(nn.functional.relu(
            self.conv4(nn.functional.relu(self.conv3(x),
                                          inplace=True)),
            inplace=True)),inplace=True))
        
        x = self.batch2(x)
        x = F.dropout(x, 0.5)
        x  = self.pool(F.relu(self.conv7(nn.functional.relu(
            self.conv6(nn.functional.relu(self.conv5(x),
                                          inplace=True)),
            inplace=True)),inplace = True))
        x = self.batch3(x)
        
        x  = self.pool(F.relu(self.conv10(nn.functional.relu(
            self.conv9(nn.functional.relu(self.conv8(x),
                                          inplace=True)),
            inplace=True)),inplace = True))
        #x = self.batch4(x)
        x = F.dropout(x, 0.5)
        #
        x = self.avg(x)
        #x = x.reshape(x.shape[0], -1)
        #to do:
        # move drop out layer, try again 
        # see if graphs a required in the report, if so make them.
        # run alex net 20 times, see validation accuracy.
        # run lenet 20 times see validation accuracy
        # run Jarnet 20 times, see accracy
        x = torch.flatten(x,1)
              
        #x.size()                                                                    
        #x = self.flat(x)
        x = nn.functional.relu(self.fc1(x),inplace=True)
        x = F.dropout(x, 0.5)
        x = nn.functional.relu(self.fc2(x),inplace=True)
        x = F.dropout(x, 0.5)
        #x = nn.functional.relu(self.fc22(x),inplace=True)
        #x = F.dropout(x, 0.5)
       # x = nn.functional.relu(self.fc23(x),inplace=True)
        #x = F.dropout(x, 0.5)
       # x = nn.functional.relu(self.fc3(x),inplace=True)
        x = self.fc3(x)
        return x
    
class AlexNet(nn.Module):
    def __init__(self):
        super(AlexNet, self).__init__()
        self.conv1 = nn.Conv2d(3, 96, kernel_size=(11,11),stride=(1,1),padding="same")
        self.pool = nn.MaxPool2d(kernel_size=3,stride=2,padding=0,dilation=1,ceil_mode=False)
        self.conv2 = nn.Conv2d(96, 256, kernel_size=(5,5),stride=(1,1),padding="same")
        self.conv3 = nn.Conv2d(256,384, kernel_size=(3,3),stride=(1,1),padding="same")
        self.conv4 = nn.Conv2d(384,384, kernel_size=(3,3),stride=(1,1),padding="same")
        self.conv5 = nn.Conv2d(384,256, kernel_size=(3,3),stride=(1,1),padding="same")
        #self.flat = nn.Flatten(end_dim=1)
        self.batch1 = nn.BatchNorm2d(96)
        self.batch2 = nn.BatchNorm2d(256)
        self.batch3 = nn.BatchNorm2d(256)
        self.fc1 = nn.Linear(256*6*6,4096)
        self.fc2 = nn.Linear(4096,4096)
        self.fc3 = nn.Linear(4096,10)
        self.drop = nn.Dropout()
        self.avg = nn.AdaptiveAvgPool2d((6,6))
    def forward(self, x):
        x = self.pool(self.batch1(nn.functional.relu(self.conv1(x))))
        x = self.pool(self.batch2(nn.functional.relu(self.conv2(x))))
        x = nn.functional.relu(self.conv4(nn.functional.relu(self.conv3(x))))
        x = self.pool(self.batch3(nn.functional.relu(self.conv5(x))))
        x = self.avg(x)
        x = torch.flatten(x,1)
        x= nn.functional.relu(self.fc1(x))
        x = nn.functional.relu(self.fc2(x))
        x = F.dropout(x,0.5)
        x = self.fc3(x)
        return x
    
class JarNet(nn.Module):
    def __init__(self):
        super(JarNet, self).__init__()
        self.conv1 = nn.Conv2d(3, 128, kernel_size=(3,3),stride=(1,1),padding="same")
        self.pool = nn.MaxPool2d(kernel_size=3,stride=2,padding=0,dilation=1,ceil_mode=False)
        self.conv2 = nn.Conv2d(128, 128, kernel_size=(3,3),stride=(1,1),padding="same")
        self.conv3 = nn.Conv2d(128,256,kernel_size=(3,3),stride=(1,1),padding="same")
        self.conv4 = nn.Conv2d(256,512,kernel_size=(3,3),stride=(1,1),padding="same")
        self.conv5 = nn.Conv2d(512,512,kernel_size=(3,3),stride=(1,1),padding="same")
        self.conv6 = nn.Conv2d(512,128,kernel_size=(3,3),stride=(1,1),padding="same")
        self.flat = nn.Flatten()
        self.fc1 = nn.Linear(128*7*7,4096)
        self.fc2 = nn.Linear(4096,4096)
        self.fc3 = nn.Linear(4096,10)
        #self.batch1 = nn.BatchNorm2d(16)
        self.batch1 = nn.BatchNorm2d(128)
        self.batch2 = nn.BatchNorm2d(512)
        self.batch3 = nn.BatchNorm2d(128)
        self.avg = nn.AdaptiveAvgPool2d((7,7))

    def forward(self, x):
        #x = self.pool(nn.functional.relu(self.conv1(x),inplace=True))
        x = nn.functional.relu(self.conv1(x),inplace=True)
        x = self.pool(nn.functional.relu(self.conv2(x),inplace=True))
        x = self.batch1(x)
        x = F.dropout(x,0.5)
        #x = self.pool(nn.functional.relu(self.conv3(x),inplace=True))
        x = nn.functional.relu(self.conv3(x),inplace=True)
        x = self.pool(nn.functional.relu(self.conv4(x),inplace=True))
        x = self.batch2(x)
        x = F.dropout(x,0.5)
        x = nn.functional.relu(self.conv5(x),inplace=True)
        x = nn.functional.relu(self.conv6(x),inplace=True)
        x = self.pool(x)
        x = self.batch3(x)
        x = F.dropout(x,0.5)
        
        x = self.avg(x)
        x = self.flat(x)
        x = nn.functional.relu(self.fc1(x),inplace=True)
        x = F.dropout(x,0.5)
        x = F.relu(self.fc2(x),inplace=True)
        x = F.dropout(x,0.5)
        x = self.fc3(x)
        return x
    
def retrain(inp,epocos,cifartrain,cifartest,device):
    if inp ==1:
        #print(len(cifartrain[0]))
        #epochs > 20 lead to overfitting
        Lenet=LeNet5()
        Lenet = Lenet.to(device)
        #print(Lenet)
        #opt = torch.optim.SGD(Lenet.parameters(),lr=0.001,momentum=0.9)
        opt = torch.optim.Adam(Lenet.parameters(),lr=0.001)
        hist = train(Lenet, cifartrain, cifartest, device, epochs=epocos*10, optimizer=opt, loss_fn=nn.CrossEntropyLoss())
        torch.save(Lenet.state_dict(), "models/Lenet.pth")
        #print("train")
        #print("test")
        print("----------------------------------------------------------\n")
        title = "Lenet-5"
        
    elif inp == 2:
        jar = modifiedvgg16()
        jar = jar.to(device)
        opt = torch.optim.SGD(jar.parameters(), lr = 0.001, momentum = 0.9)
        #opt = torch.optim.Adam(jar.parameters(),lr=0.001)
        hist = train(jar, cifartrain, cifartest, device, epochs=epocos*10, optimizer=opt, loss_fn=nn.CrossEntropyLoss())
        torch.save(jar.state_dict(), "models/modifiedvgg16.pth")
        #print("train")
        #print("test")
        print("----------------------------------------------------------\n")
        title = "Modified VGG16"
    elif inp ==3 :
        print("alex")
        #alex = torchvision.models.alexnet()
        #print(alex)
        alex = AlexNet()
        alex = alex.to(device)
        opt = torch.optim.SGD(alex.parameters(), lr = 0.001, momentum = 0.9)
        #opt = torch.optim.Adam(jar.parameters(),lr=0.001)
        #print("opimized")
        hist = train(alex, cifartrain, cifartest, device, epochs=epocos*10, optimizer=opt, loss_fn=nn.CrossEntropyLoss())
        torch.save(alex.state_dict(), "models/AlexNet.pth")
        print("----------------------------------------------------------\n")
        #mobilenet = torchvision.models.MobileNetV2()
        #print(mobilenet)
        title = "AlexNet"
        
    elif inp ==4:
        print("JarNet")
        jar = JarNet()
        jar = jar.to(device)
        opt = torch.optim.SGD(jar.parameters(), lr = 0.001, momentum = 0.9)
        #opt = torch.optim.Adam(jar.parameters(),lr=0.001)
        #print("opimized")
        hist = train(jar, cifartrain, cifartest, device, epochs=epocos*10, optimizer=opt, loss_fn=nn.CrossEntropyLoss())
        torch.save(jar.state_dict(), "models/JarNet.pth")
        print("----------------------------------------------------------\n")
        title = "JarNet"
    return title, hist
#summary(net,input_size=(1,3,32,32))
def modelselector(selection):
    try:
        if selection ==1 :
            model = LeNet5()
            model.load_state_dict(torch.load('models/Lenet.pth'))
            model.eval()
        elif selection ==2 :
            model = modifiedvgg16()
            model.load_state_dict(torch.load('models/modifiedvgg16.pth'))
            model.eval()
        elif selection ==3 :
            model = AlexNet()
            model.load_state_dict(torch.load('models/AlexNet.pth'))
            model.eval()
        else:
            model = JarNet()
            model.load_state_dict(torch.load('models/JarNet.pth'))
            model.eval()
        return model
    except:
        print("model not found")

def main():
    # setup device
    

    
    #print("prepare the data")
    device = (
        "cuda"
        if torch.cuda.is_available()
        else "cpu"
    )
    print(f"Using {device} device, we do not recomend using cpu for training")
    cifartrain,cifartest = prepareData()
    
    
    #isretraining = userInput("\ndo you want to retrain?\n1. Yes, 2. No ",2)
    isretraining = 1
    if isretraining == 1:    
        inp = userInput("\n1. leNet5 \n2. modified vgg16 \n3. Alexnet \n4. JarNet \n5. I am finished and wish to exit",5)
        if inp != 5:
            epocos = userInput("\n1. 10 epochs \n2. 20 epochs \n3. 30 epochs \n4. 40 epochs \n5.50 epochs ", 5)
            title, hist = retrain(inp,epocos,cifartrain,cifartest,device)
        else:
            print("thanks!")
            #hist=[0]
        try:
            xlabs = [i for i in range(len(hist["val_acc"]))]
            #print(len(hist))
            #print(hist)
            #for i in range(len(hist["val_acc"])):
            #    xlabs.append(i)
                
            plt.plot(xlabs, hist["train_acc"], label="training acc")
            plt.plot(xlabs,hist["val_acc"],label="validation acc")
            plt.legend()
            plt.title(title + " accuracy")
            plt.show()
            plt.plot(xlabs,hist["train_loss"],label="training loss")
            plt.plot(xlabs,hist["val_loss"],label="validation loss")
            plt.title(title + " loss")
            plt.legend()
            plt.show()
            #print("SMARTJAR\n\n-------------------------------------------------\n")
            #save model as Title
            
            main()
        except:
            print("goodbye")
        #selectmodel = userInput("\n1. leNet5 \n2. modified vgg16 \n3. Alexnet \n4. JarNet \n5. I am finished and wish to exit",5)
        #model = modelselector(selectmodel)
        #display 9 images
        #select 1
        #eval
        #again? 
    
    
if __name__ == "__main__":
    main()
    