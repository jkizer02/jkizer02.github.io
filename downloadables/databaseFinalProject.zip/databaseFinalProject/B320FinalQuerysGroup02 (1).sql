--select * from studentmajor --add concentration and end date
--At the end of each academic year (i.e., August), Dr. Canada has to report the number of
--classes and number of students taught during that academic year by each instructor who taught 
--at least 1 computer science course.

--/////////////////////////////drop statements--/////////////////////////////
drop proc queryi
go 
drop proc queryh
go
drop proc queryg
go
drop proc queryf
go
drop proc querye
go
drop proc queryd
go
drop proc queryc 
go
drop proc queryb
go
drop proc queryA
go

drop view GPA
go

--/////////////////////////////populate veiws--/////////////////////////////

create view GPA 
as 
select StudentMajor.studentID, classterms.classTermID,majorAdvisor.ProfessorID, Semester + ' ' + classtermsyear as currentTerm ,MajoriD, (sum(gradePoint*credits)/sum(credits)) as GPA--classTermID,
from grades inner join transcriptlineItem on Grade=gradeLetter
inner join CourseOfferings on CourseOfferings.CoursesOfferedID = transcriptlineItem.CoursesOfferedID
inner join StudentMajor on transcriptlineItem.StudentID = StudentMajor.StudentID
inner join ClassTerms on ClassTerms.ClassTermID = CourseOfferings.classTermID
inner join majorAdvisor on majorAdvisor.studentMajorID = StudentMajor.studentMajorID
where (MajorID =11 or majorID =29) 
group by StudentMajor.studentID,classterms.classTermID,Semester + ' ' + classtermsyear,MajorID, majorAdvisor.ProfessorID
go

-------------------------Start of query A


--input: the studentID of the student you want to generate a transcript for. 
--process: joins transcriptlineitems with students, courseofferings, coursecatalog, classterms, and subjects
--output: that students full transcript.
create proc queryA
@student as int
as
select fname,lname,subjectname,courseNumber,section, credits, crn, grade, semester, semester, classtermsyear as [Year]
from transcriptlineitem 
INNER JOIN students
	on transcriptlineitem.studentID = students.studentID
INNER JOIN courseofferings 
	on transcriptlineitem.coursesofferedID = courseofferings.coursesofferedid
inner join coursesCatalog 
	on coursescatalog.courseID = courseofferings.courseID
inner join subjects on subjects.subjectid = coursescatalog.subjectid
inner join classterms on classterms.classtermid=courseofferings.classtermid
where transcriptlineitem.studentID = @student
order by transcriptlineitem.StudentID asc
go
-----------------------------------------------------------

--query b ------------------------------------------------------------
--select majorname,studentmajor.majorID, count(studentmajor.majorID) as [Student Count]--, count(StartDate) as sumstu
--from studentmajor INNER JOIN majors
--on majors.majorID = studentmajor.majorID
--INNER JOIN Students
--on Students.studentID = studentmajor.studentID
----INNER JOIN Courseofferings 
----on courseofferings.
--where completionstatus = 'In progress'
--group by studentmajor.majorID, majorname, StartDate
-- need class term id for class terms year

create proc queryB
AS
select majorname, year(startdate) as [Student Year],  count(studentmajor.studentid) as [Student Count]--startdate,majorname,studentmajor.majorID, students.studentid,--, count(StartDate) as sumstu
from studentmajor 
INNER JOIN majors
on majors.majorID = studentmajor.majorID
INNER JOIN Students
on Students.studentID = studentmajor.studentID
where completionStatus = 'In Progress' 
group by majorname, startdate

GO


------------------------------------------------------------

--select * from classterms
--select * from Studentmajor
--select * from professors
------------------------ Querie C ----------------------------------


--input:	the year the that you are looking at the number of courses offered in.
--process: joins courseofferings with coursecatalog,professors, and classterms. then filters to only show the compsci department
--output:  a table showing the number students and courses taught by each professor that year.
go
create proc queryc
@year as int
as
select fullname as [Professor Name],classterms.classtermsyear as [Year], sum(studentsenrolled) as students, count(coursesofferedID) as Classes--, course_identification --, count(courseofferings.coursesofferedID) as classcount 
from courseofferings
INNER JOIN coursescatalog
on courseofferings.courseID = coursescatalog.courseID
INNER JOIN professors
on professors.professorID = courseofferings.professorID
INNER JOIN classterms
on Classterms.classtermID = courseofferings.classtermID
where (Course_identification like '%CSCI%' or course_identification like '%ISAT%') and classtermsyear = @year
group by professors.professorID, fullname, classterms.classtermsyear--, course_identification
go

-------------------------------- query D -----------------

/*
QUERY D - Each semester, Dr. Canada has to report the number of Computer Science students who successfully 
completed all courses with a grade of C or better. This information typically has to be broken out by student 
classification (i.e., 1st year CSCI, 2nd year CSCI, 3rd year CSCI, 4th year CSCI, 1st year ISAT, etc) and semester 
(Spring 2021, Fall 2021, etc.)
*/

--input: the current semester and year
--process: it counts the number of students who start date is that many years from the current year
--output: a single table of 4 rows showing the numbers
create proc queryd
@semester as varchar(20),
@year as int
as
select 'first years' as [Student year],count(studentID) as [Number of students]
from (
select majorname, year(startdate) as startDate,studentmajor.studentid --count(studentmajor.studentid) as [Student Count]--startdate,majorname,studentmajor.majorID, students.studentid,--, count(StartDate) as sumstu
from studentmajor 
INNER JOIN majors
on majors.majorID = studentmajor.majorID
INNER JOIN Students
on Students.studentID = studentmajor.studentID
inner join transcriptlineItem 
on transcriptlineItem.studentID = students.studentID
where completionstatus = 'In progress' and year(startDate) = @year-1
and grade in ('A','B','C','C+','B+') and students.studentid not in (
select studentid
from transcriptlineitem
inner join courseofferings on courseofferings.coursesofferedid = transcriptlineitem.coursesofferedid
inner join classterms on classterms.classtermid = courseofferings.classtermid
where grade in ('W','WF','F','D') and semester + ' '+ classtermsyear =@semester + ' '+ cast(@year as varchar(4))--@semeste
)
group by majorname, startdate, studentmajor.studentid --startdate,majorname,studentmajor.majorID, students.studentid--, StartDate
) as freshy
union 
select 'Second years' as [Student year],count(studentID) as [Number of students]
from (
select majorname, year(startdate) as startDate,studentmajor.studentid --count(studentmajor.studentid) as [Student Count]--startdate,majorname,studentmajor.majorID, students.studentid,--, count(StartDate) as sumstu
from studentmajor 
INNER JOIN majors
on majors.majorID = studentmajor.majorID
INNER JOIN Students
on Students.studentID = studentmajor.studentID
inner join transcriptlineItem 
on transcriptlineItem.studentID = students.studentID
where completionstatus = 'In progress' and year(startDate) = @year-2
and grade in ('A','B','C','C+','B+') and students.studentid not in (
select studentid
from transcriptlineitem
inner join courseofferings on courseofferings.coursesofferedid = transcriptlineitem.coursesofferedid
inner join classterms on classterms.classtermid = courseofferings.classtermid
where grade in ('W','WF','F','D') and semester + ' '+ classtermsyear =@semester + ' '+ cast(@year as varchar(4))--@semeste
)
group by majorname, startdate, studentmajor.studentid --startdate,majorname,studentmajor.majorID, students.studentid--, StartDate
) as soph
union
select 'Third years' as [Student year],count(studentID) as [Number of students]
from (
select majorname, year(startdate) as startDate,studentmajor.studentid --count(studentmajor.studentid) as [Student Count]--startdate,majorname,studentmajor.majorID, students.studentid,--, count(StartDate) as sumstu
from studentmajor 
INNER JOIN majors
on majors.majorID = studentmajor.majorID
INNER JOIN Students
on Students.studentID = studentmajor.studentID
inner join transcriptlineItem 
on transcriptlineItem.studentID = students.studentID
where completionstatus = 'In progress' and year(startDate) = @year-3
and grade in ('A','B','C','C+','B+') and students.studentid not in (
select studentid
from transcriptlineitem
inner join courseofferings on courseofferings.coursesofferedid = transcriptlineitem.coursesofferedid
inner join classterms on classterms.classtermid = courseofferings.classtermid
where grade in ('W','WF','F','D') and semester + ' '+ classtermsyear =@semester + ' '+ cast(@year as varchar(4)))
group by majorname, startdate, studentmajor.studentid --startdate,majorname,studentmajor.majorID, students.studentid--, StartDate
) as junior
union
select 'fourth years' as [Student year],count(studentID) as [Number of students]
from (
select majorname, year(startdate) as startDate,studentmajor.studentid --count(studentmajor.studentid) as [Student Count]--startdate,majorname,studentmajor.majorID, students.studentid,--, count(StartDate) as sumstu
from studentmajor 
INNER JOIN majors
on majors.majorID = studentmajor.majorID
INNER JOIN Students
on Students.studentID = studentmajor.studentID
inner join transcriptlineItem 
on transcriptlineItem.studentID = students.studentID
where completionstatus = 'In progress' and year(startDate) = @year-4
and grade in ('A','B','C','C+','B+') and students.studentid not in (
select studentid
from transcriptlineitem
inner join courseofferings on courseofferings.coursesofferedid = transcriptlineitem.coursesofferedid
inner join classterms on classterms.classtermid = courseofferings.classtermid
where grade in ('W','WF','F','D') and semester + ' '+ classtermsyear =@semester + ' '+ cast(@year as varchar(4))--@semeste
)
group by majorname, startdate, studentmajor.studentid --startdate,majorname,studentmajor.majorID, students.studentid--, StartDate
) as senior
go


--------	--------------			----Query E --
--Liste every student For each of these courses, 
--	the number and percentage of computer science students who successfully 
--complete the course with a grade of C or better must be listed2

--unfinished

create proc querye
@term as varchar(20)
as
select subjectName, courseNumber,courseTitle,semester,classtermsyear,count(passed.grade) as [passedStudents], 
	cast(count(passed.grade)*100/count(*) as varchar)+'%' as precentagePassed,
	count(failed.grade) as FailedStudents,
	cast(count(failed.grade)*100/count(*) as varchar)+'%' as precentageFailed
from courseOfferings 
inner join classterms 
	on classterms.classtermid=courseofferings.classtermID
inner join coursesCatalog
	on coursescatalog.courseID = courseOfferings.courseid
inner join subjects
	on subjects.subjectid = coursescatalog.subjectid
inner join (
select coursesOfferedid,grade,studentID
from transcriptlineitem 
where grade in ('A','B','B+','C','C+') 
)as passed
	on passed.coursesofferedID =courseofferings.coursesofferedid
inner join students 
	on students.studentID =passed.studentID
left join ( 
select coursesOfferedid,grade,studentID
from transcriptLineitem 
where grade in('W','WF','F','D')
) as failed
	on failed.coursesofferedID =courseofferings.coursesofferedid
where semester + ' '+classtermsYear = @term
	and subjectname in ('CSCI','ISAT')  --and failed.grade in ('D+','D','F','WF','WP','W')
group by subjectName, courseNumber,courseTitle,semester,classtermsyear
go


------------------------------Query F


--input: non
--process: joins courseofferings with coursecatalog, professors and classterms. 
--		   then filters where students enrolled < 10 and the subject is csci or isat
--output
go
create proc queryf
as
select classtermsyear, semester, CourseTitle,subjectname, CourseNumber,
FullName, studentsenrolled--, count(courseofferings.coursesofferedID) as classcount 
from courseofferings
INNER JOIN coursescatalog
on courseofferings.courseID = coursescatalog.courseID
INNER JOIN professors
on professors.professorID = courseofferings.professorID
INNER JOIN classterms
on Classterms.classtermID = courseofferings.classtermID
inner join subjects on subjects.subjectid = coursescatalog.subjectID
where (subjectName like '%ISAT%' Or subjectName like '%CSCI%')and studentsenrolled < 10 --and classtermsyear >= 2020
order by subjectname,studentsEnrolled asc
go


----------query g

--create function, passs in the semester you are searching as Semester + space + year


--input: the term you want to check in the form 'Semester Year'
--proccess: uses a union on results of the gpa veiw to group each individual catagory together. 
--output: the number of students in each GPA range by a semester.
create proc queryg
@semeste as varchar(30)
as
select 'A' as Range, count(GPA) as 'number of students'
from GPA
where GPA =4.0 and currentTerm = @semeste
union
 select 'B+' as Range, count(GPA) as 'Number of Students'
from GPA
where GPA >= 3.5 and GPA < 4.0 and currentTerm =@semeste
union
 select 'B' as Range ,count(GPA) as 'Number of Students'
from GPA
where GPA >= 3.0 and GPA < 3.5 and currentTerm =@semeste
union
 select 'C+' as Range ,count(GPA) as 'Number of Students'
from GPA
where GPA >= 2.5 and GPA < 3 and currentTerm =@semeste
union
 select 'C' as Range ,count(GPA) as 'Number of Students'
from GPA
where GPA >= 2.0 and GPA < 2.5 and currentTerm =@semeste
union
 select 'D+' as Range ,count(GPA) as 'Number of Students'
from GPA
where GPA >= 1.5 and GPA < 2 and currentTerm =@semeste
union
 select 'D' as Range ,count(GPA) as 'Number of Students'
from GPA
where GPA >= 1.0 and GPA < 1.5 and currentTerm =@semeste
union
 select 'F' as Range ,count(GPA) as 'Number of Students'
from GPA
where GPA <1  and currentTerm =@semeste;
go


--end g

--////////////////////////////////query h/////////////////////////////////


--input: the two semesters you want to compare given in the format 'Semester Year' the first being the more recent semester.
--process: 
--output the student and their advisor with a gpa lower in the more recent semester then in previous semesters. 
create proc queryh
@firstParam as varchar(20), 
@SecondParam as varchar(20)
as

select students.fname + ' ' + students.lname as 'StudentName', professors.fullname as 'Advisor Name', gpresent.currentterm,MajorName, gpresent.gpa as [Lower semester],gpresent.currentTerm, gpast.gpa as [Highersemester],gpast.currentTerm
from gpa as gpast 
inner join gpa as gpresent 
	on gpast.studentId=gpresent.studentId 
inner join professors 
	on professors.professorID = gpast.professorID 
inner join students 
	on students.studentID =gpast.studentid
inner join majors 
	on gpresent.majorID = majors.majorID
where (gpresent.currentTerm = @firstParam and gpast.currentterm=@secondParam ) and gpresent.gpa<gpast.gpa
order by gpast.professorID
go


--////////////////////////////////////////query i///////////////////////////////////////


--input non
--process: joins transcriptlineitem to courseofferings,students,classterms,studentajor,majoradvisor, and professors. 
--		   then filters for failed classes. 
--output: the advisees who failed a class and are either retaking it now, have already retaken it, or have yet to retake it
create proc queryi 
as

select fullname as Advisor, students.fname + ' '+ students.lname as [Student Name],course_identification, Grade, semester, classtermsyear
from transcriptlineitem 
inner join courseOfferings 
	on transcriptlineitem.coursesOfferedID = courseofferings.coursesofferedID
inner join students 
	on students.studentID = transcriptlineitem.studentid 
inner join classterms 
	on classterms.classtermID = courseofferings.classtermid
inner join studentMajor 
	on students.studentID = studentmajor.studentID
inner join majorAdvisor 
	on majorAdvisor.studentMajorID = StudentMajor.studentMajorID
inner join professors 
	on professors.professorid = majoradvisor.professorID
inner join coursesCatalog 
	on coursesCatalog.courseID = courseofferings.courseid
where coursesCatalog.courseID in (
	select courseofferings.courseID -- fname+' '+lname as studentName 
	from transcriptlineitem 
	inner join courseOfferings 
		on transcriptlineitem.coursesofferedID = courseOfferings.coursesOfferedID 
	where grade in ( 'F', 'WF','WP','W','D') ) 
and students.studentID in ( 
	select transcriptlineitem.studentID -- fname+' '+lname as studentName 
	from transcriptlineitem 
	inner join courseOfferings 
		on transcriptlineitem.coursesofferedID = courseOfferings.coursesOfferedID 
	where grade in ( 'F', 'WF','WP','W','D') )
	order by majoradvisor.advisorid,[semester ]desc,classtermsyear asc
go


--/////////////////////////////////////////////////////// execs statements
--exec queryA 30				-- any studentID
--exec queryB					-- no parameters 
--exec queryc 2020				--any year
--exec queryD 'Spring', 2022	-- any semester, year where semester is varchar and year is int
--exec queryE 'Spring 2022'		-- any semester + ' ' + year
--exec queryf					-- no parameters
--exec queryg 'Spring 2022'		-- any semester + ' ' + year
--exec queryh 'Spring 2022','Fall 2021' -- any two semesters
--exec queryi					-- no paremters
